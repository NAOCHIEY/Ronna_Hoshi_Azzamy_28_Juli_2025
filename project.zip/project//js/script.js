document.getElementById("naocheese").addEventListener('submit', function(event) {
        event.preventDefault(); //Mencegah form untuk submit secara default
    
        //Mendapatkan nilai username dan password
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var erormessage = document.getElementById('eror-message');
     
        //Validasi Username dan password
        if (username === '' || password === '') {
            erormessage.textContent = 'wajib diisi!!';
        } else if (username !== 'hoshi' || password !=='1414') {
            errorMessage.textContent = 'username atau password salah';
        } else {
            errorMessage.textContent = ''
            alert('sukses login');
        }
        
    });